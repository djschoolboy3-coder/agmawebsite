// Sticky header + dark-aware
(function(){
  const header=document.getElementById('header');
  if(header){
    const onScroll=()=>header.classList.toggle('scrolled',window.scrollY>40);
    window.addEventListener('scroll',onScroll);onScroll();
  }
  // Mobile menu
  const burger=document.getElementById('burger'),mm=document.getElementById('mobileMenu');
  if(burger&&mm){
    burger.addEventListener('click',()=>{mm.classList.toggle('open')});
    mm.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>mm.classList.remove('open')));
  }
  // FAQ accordion
  document.querySelectorAll('.faq-q').forEach(q=>{
    q.addEventListener('click',()=>{
      const item=q.parentElement,a=q.nextElementSibling,open=item.classList.contains('open');
      const parent=q.closest('.faq-wrap');
      parent.querySelectorAll('.faq-item').forEach(i=>{i.classList.remove('open');i.querySelector('.faq-a').style.maxHeight=null});
      if(!open){item.classList.add('open');a.style.maxHeight=a.scrollHeight+'px'}
    });
  });
  // Reveal
  const io=new IntersectionObserver((entries)=>{
    entries.forEach((e,i)=>{if(e.isIntersecting){setTimeout(()=>e.target.classList.add('in'),i*60);io.unobserve(e.target)}});
  },{threshold:.12,rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
})();
